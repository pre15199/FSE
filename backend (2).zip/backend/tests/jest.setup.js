
// jest.config.js
jest.setTimeout(1000);
module.exports = {
    // Other Jest configurations...
  
    testEnvironmentOptions: {
      port: 5001, // Change this to a different port number
    },
 
  };

